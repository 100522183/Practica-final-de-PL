#include <stdio.h>
main() {
    int i;
    for(i=0; i<10; i=i+1) {
    }
}
//@ (main)