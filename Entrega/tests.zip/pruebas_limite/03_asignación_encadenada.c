main() {
    int a, b;
    a = b = 5;
}
//@ (main)
