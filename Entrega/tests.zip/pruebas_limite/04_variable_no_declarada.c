main() {
    noDeclarada = 42;
}
//@ (main)
