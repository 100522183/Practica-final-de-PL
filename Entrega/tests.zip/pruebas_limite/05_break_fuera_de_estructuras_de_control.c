main() {
    int a = 1;
    switch (a){
        case 1:
            break;
    }
}
//@ (main)
